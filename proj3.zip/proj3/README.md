# Build Your Own World Design Document

**Partner 1:**
Surabhi Haniyur
**Partner 2:**
Adel Burieva
## Classes and Data Structures
1. Core.Main.java : entry point for the program. Interacts with command line args and Core.Engine.java.
2. Core.Engine.java: creates world. Interacts with Main and TERenderer.
3. TileEngine.TERenderer.java: prints/displays the world. Interacts with TileSet, TETile, and Engine.
4. TileEngine.TETile.java: represents a single tile in the world. Interacts with TERenderer, TileSet.
5. TileEngine.Tileset.java: represents the library of tiles used in the world. Interacts with TETile, TERenderer.




## Algorithms

## Persistence
