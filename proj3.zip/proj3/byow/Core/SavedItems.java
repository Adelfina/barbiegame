package byow.Core;

import byow.TileEngine.TETile;

import java.io.Serializable;
import java.util.Random;

public class SavedItems implements Serializable {

    TETile avatar;
    Position currentPosition;
    Random seed;
    TETile[][] world;


    public SavedItems(Engine savedEngine) {
        this.avatar = savedEngine.avatar;
        this.currentPosition = savedEngine.currentPosition;
        this.seed = savedEngine.seed;
        this.currentPosition = savedEngine.currentPosition;
        this.world = savedEngine.world;
    }

}
