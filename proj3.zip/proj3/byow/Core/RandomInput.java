package byow.Core;

import java.util.Random;

public class RandomInput implements InputSourceByoW {

    Random r;
    public RandomInput(Random random) {
        r = random;
    }
    @Override
    /** Returns a random letter between a and z.*/
    public char getNextKey() {
        return (char) (r.nextInt(26) + 'A');
    }

    @Override
    public boolean possibleNextInput() {
        return true;
    }
}