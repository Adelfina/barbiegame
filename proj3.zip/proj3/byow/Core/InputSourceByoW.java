package byow.Core;

public interface InputSourceByoW {

    public char getNextKey();
    public boolean possibleNextInput();

}