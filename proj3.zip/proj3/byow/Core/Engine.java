package byow.Core;
import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;
import edu.princeton.cs.algs4.StdDraw;
import org.checkerframework.checker.units.qual.K;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;

import java.util.Arrays;
import java.util.Random;

public class Engine implements Serializable {
    TERenderer ter = new TERenderer();
    /* Feel free to change the width and height. */
    public static final int WIDTH = 80;
    public static final int HUD_HEIGHT = 1;
    public static final int HEIGHT = 30;

    // Maximum number of rooms
    public static final int MAXS = 15;
    // Minimum number of rooms
    public static final int MINS = 10;
    // Maximum tiles of dimension of a room
    public static final int MAXRS = 10;
    public static final int MAX_ROOM_DIM = 10;
    // Minimum tile dimension of a room.
    public static final int MINRS = 5;
    public static final int MIN_ROOM_DIM = 5;

    // Variables for spacing in the displays
    public static final int TILE_SIZE = 16;
    public static final int SPACE_FROM_TITLE = 10;
    public static final int SPACING = 7;

    // INSTANCE VARIABLES!!

    // the player's avatar (can be changed)
    public TETile avatar = Tileset.STEREOTYPICAL;

    public static final TETile stereotypical = Tileset.STEREOTYPICAL;
    public static final TETile cowgirl = Tileset.COWGIRL;

    // the state of the current world
    public TETile[][] world;
    public Random seed;
    public ArrayList<Character> commandList = new ArrayList<>();
    public Position currentPosition;
    private boolean isSaved = false;
    private TETile[][] currentWorld; // used exclusively for saving progress


    /**
     * Method used for exploring a fresh world. This method should handle all inputs,
     * including inputs from the main menu.
     */

    // All this method does is tell us when the game is over.
    public void interactWithKeyboard() {
        // boolean first = true;
        while (true) {
            /*if (first) {
                String musicPath = "byow/Music/DTN.wav";
                MusicPlayer.PlayMusic(musicPath);
                first = false;
            }*/

            if (StdDraw.hasNextKeyTyped()) {
                char key = StdDraw.nextKeyTyped();

                // Example: If 'q' is pressed, quit the game
                if (key == 'q' || key == 'Q') {
                    // Quit the game and save if necessary
                    if (isSaved) {
                        System.out.println("Successfully Saved");
                    } else {
                        savePlay();
                        System.out.println("Quitting after saving");
                    }
                    System.exit(0);
                } else {
                    // Wait for the next character to check if it's "q" for saving and quitting
                    userMenuKey();
                }
                // ter.renderFrame(world);
            }

        }

    }

    /**
     * Method used for autograding and testing your code. The input string will be a series
     * of characters (for example, "n123sswwdasdassadwas", "n123sss:q", "lwww". The engine should
     * behave exactly as if the user typed these characters into the engine using
     * interactWithKeyboard.
     *
     * Recall that strings ending in ":q" should cause the game to quite save. For example,
     * if we do interactWithInputString("n123sss:q"), we expect the game to run the first
     * 7 commands (n123sss) and then quit and save. If we then do
     * interactWithInputString("l"), we should be back in the exact same state.
     *
     * In other words, running both of these:
     *   - interactWithInputString("n123sss:q")
     *   - interactWithInputString("lww")
     *
     * should yield the exact same world state as:
     *   - interactWithInputString("n123sssww")
     *
     * @param input the input string to feed to your program
     * @return the 2D TETile[][] representing the state of the world
     */
    public TETile[][] interactWithInputString(String input) {
        // passed in as an argument, and return a 2D tile representation of the
        // world that would have been drawn if the same inputs had been given
        // to interactWithKeyboard().
        //
        // See proj3.byow.InputDemo for a demo of how you can make a nice clean interface
        // that works for many different input types.





        // TODO change this so that this is all within the thing that parses the input
        // Seed-related
        long seed = Long.valueOf(input.hashCode());
        Random random = new Random(seed);
        createInitialWorld(random);

        // The following code makes hud constantly update!
        /*boolean yes = true;
        boolean first = true;
        // draws the world to the screen
        while (yes) {
            if (first) {
                String musicPath = "byow/Music/DTN.wav";
                MusicPlayer.PlayMusic(musicPath);
                first = false;
            }
            ter.renderFrame(world);
            hud(world);
        }*/


        // draws the world to the screen
        // ter.renderFrame(world);
        /*String musicPath = "byow/Music/DTN.wav";
        MusicPlayer.PlayMusic(musicPath);*/
        currentWorld = world;
        return world;

    }

    /** FUNCTIONS FOR INTERACTWITHSTRING SPECIFICALLY */
    public void createInitialWorld(Random currRandom) {
        this.ter.initialize(WIDTH, HEIGHT + HUD_HEIGHT);
        this.world = new TETile[WIDTH][HEIGHT];
        // fill initial world with all nothing tiles
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                world[i][j] = Tileset.NOTHING;
            }
        }
        // create the randomized world
        createRoom( currRandom);

    }

    // Takes in the String, calls the necessary functions, displays the tile array, and displays the HUD.
    public void stringMenuKey(StringInput input) {
        while (input.possibleNextInput()) {
            Character key = input.getNextKey();
            key = Character.toUpperCase(key);

            if (key == 'N') {
                String seedAndAfter = input.getInput().substring(input.getIndex());

            }
            // TODO finish all of this!!!

        }
    }



    /** UI DISPLAYS */
    public void mainMenu() {
        // Initialize a new STD Canvas
        StdDraw.setCanvasSize(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
        Font font = new Font("Monaco", Font.BOLD, TILE_SIZE - 2);
        StdDraw.setFont(font);
        StdDraw.setXscale(0, WIDTH);
        StdDraw.setYscale(0, WIDTH);
        StdDraw.clear(new Color(0, 0, 0));

        StdDraw.enableDoubleBuffering();

        // Draw title name of game
        Font titleFont = new Font("Monaco", Font.BOLD, TILE_SIZE*3);
        StdDraw.setFont(titleFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.text(WIDTH/2, HEIGHT*2, "Barbie: The Movie: The Game");
        // it shows up!!

        // Draw main menu options for N L Q A R
        Font optionsFont = new Font("Monaco", Font.BOLD, TILE_SIZE*2);
        StdDraw.setFont(optionsFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE, "New Game (N)");
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE - SPACING, "Load Game (L)");
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*2, "Change Avatar (A)");
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*4, "Quit (:Q)");


        StdDraw.show();
        this.userMenuKey();
    }

    public void menuWithoutMusic() {
        StdDraw.setCanvasSize(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
        Font font = new Font("Monaco", Font.BOLD, TILE_SIZE - 2);
        StdDraw.setFont(font);
        StdDraw.setXscale(0, WIDTH);
        StdDraw.setYscale(0, WIDTH);
        StdDraw.clear(new Color(0, 0, 0));

        StdDraw.enableDoubleBuffering();

        // Draw title name of game
        Font titleFont = new Font("Monaco", Font.BOLD, TILE_SIZE*3);
        StdDraw.setFont(titleFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.text(WIDTH/2, HEIGHT*2, "Barbie: The Movie: The Game");
        // it shows up!!

        // Draw main menu options for N L Q A R
        Font optionsFont = new Font("Monaco", Font.BOLD, TILE_SIZE*2);
        StdDraw.setFont(optionsFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE, "New Game (N)");
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE - SPACING, "Load Game (L)");
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*2, "Change Avatar (A)");
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*4, "Quit (:Q)");


        StdDraw.show();
    }

    public static void avatarMenu() {
        StdDraw.setCanvasSize(WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
        Font font = new Font("Monaco", Font.BOLD, TILE_SIZE - 2);
        StdDraw.setFont(font);
        StdDraw.setXscale(0, WIDTH);
        StdDraw.setYscale(0, WIDTH);
        StdDraw.clear(new Color(0, 0, 0));

        StdDraw.enableDoubleBuffering();

        // Draw title
        Font titleFont = new Font("Monaco", Font.BOLD, TILE_SIZE*3);
        StdDraw.setFont(titleFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.text(WIDTH/2, HEIGHT*9/4, "Choose Your Avatar");

        // Draw options
        Font optionsFont = new Font("Monaco", Font.BOLD, TILE_SIZE*2);
        StdDraw.setFont(optionsFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.picture(WIDTH/4, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*2,
                "byow/Avatars/stereotypical-big.png");
        StdDraw.text(WIDTH/4, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*5, "Stereotypical Barbie (X)");
        StdDraw.picture(WIDTH/4*3, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*2,
                "byow/Avatars/cowgirl-big.png");
        StdDraw.text(WIDTH/4*3, HEIGHT*2 - SPACE_FROM_TITLE - SPACING*5, "Cowgirl Barbie (Y)");


        StdDraw.show();
    }

    public static void textUsage(String text) {
        StdDraw.clear(new Color(0, 0, 0));
        Font optionsFont = new Font("Monaco", Font.BOLD, TILE_SIZE*2);
        StdDraw.setFont(optionsFont);
        StdDraw.setPenColor(Color.white);
        StdDraw.text(WIDTH/2, HEIGHT*2 - SPACE_FROM_TITLE, text);
        StdDraw.show();
    }

    /** HANDLING USER INPUTS */


    // This function handles the inputs on the main menu for the keyboard version of this program.
    public void userMenuKey() {
        String musicPath = "byow/Music/DTN.wav";
        MusicPlayer.PlayMusic(musicPath);
        boolean saveColon = false;
        boolean nWasCalled = false;
        boolean lWasCalled = false;
        while(true) {
            if (StdDraw.hasNextKeyTyped()) {
                Character key = StdDraw.nextKeyTyped();

                switch (Character.toUpperCase(key)) {
                    case 'N':
                        if (nWasCalled || lWasCalled) {
                            break;
                        }
                        saveColon = false;
                        nWasCalled = true;
                        // this.interactWithInputString(newWorldMapHandle());
                        long seed = Long.valueOf(newWorldMapHandle().hashCode());
                        Random random = new Random(seed);
                        createInitialWorld(random);
                        movement();
                        break;
                    case 'L':
                        // load the current world
                        // need to call another function that will handle the movements
                        // handleLoadWorld();
                        if (nWasCalled || lWasCalled) {
                            break;
                        }
                        if(reload()) {
                            movement();
                        }
                        lWasCalled = true;
                        saveColon = false;
                        break;
                    case ':':
                        interactWithKeyboard();
                        saveColon = true;
                        break;
                    case 'A' :
                        // change the avatar's appearance
                        avatarMenu();
                        changeAvatar();
                        menuWithoutMusic();
                        saveColon = false;
                        break;
                    /*case 'Q' :
                        if (!saveColon) {
                            // TODO save the current world
                            System.exit(0);
                        }
                        break;*/
                    /*default:
                        System.out.println("Invalid choice! Please select a valid option.");
                        mainMenu();*/

                }
            }

        }
    }

    // Changing avatars function for keyboard (since ambition feature only)
    public void changeAvatar() {
        InputSourceByoW inputKeys = new KeyboardInput();
        boolean done = false;

        TETile thisAvatar;
        while (inputKeys.possibleNextInput() && !done) {
            Character key = inputKeys.getNextKey();
            key = Character.toUpperCase(key);
            if (key == 'X') {
                thisAvatar = stereotypical;
                done = true;
            }
            else if (key == 'Y') {
                thisAvatar = cowgirl;
                done = true;
            }


        }
    }


    // This function handles the inputs that occur once you're in a world.
    public void movement() {
        // TODO: make a menu that handles inputs for movements once in the loaded world & handles the quit
        boolean colonPressed = false;
        InputSourceByoW inputKeys = new KeyboardInput();
        while (inputKeys.possibleNextInput()) {
            StdDraw.clear();
            ter.renderFrame(world);
            hud();
            // TODO add call to lighting function
            // FIXME maybe introduce a global variable instead
            Character key = inputKeys.getNextKey();
            key = Character.toUpperCase(key);
            switch (key) {
                case 'W' :
                    moveUp();
                    colonPressed = false;
                    break;
                case 'A' :
                    moveLeft();
                    colonPressed = false;
                    break;
                case 'S' :
                    moveDown();
                    colonPressed = false;
                    break;
                case 'D' :
                    moveRight();
                    colonPressed = false;
                    break;
                case ':' :
                    colonPressed = true;
                    interactWithKeyboard();
                    break;
                case 'Q' :
                    if (colonPressed) {
                        // TODO remember to save the world!
                        System.exit(0);
                    }
                    break;
                case 'B' :
                    MusicPlayer.PlaySoundEffect("byow/Music/hi-barbie.wav");
                    colonPressed = false;
                    break;
                case 'K' :
                    MusicPlayer.PlaySoundEffect("byow/Music/hi-ken.wav");
                    colonPressed = false;
                    break;
            }

        }
    }

    /** CREATING NEW WORLD */

    // Returns the string of the map seed
    public String newWorldMapHandle() {
        String number = "";
        textUsage("Please enter anything and then end with S");
        ArrayList<Character> lList = new ArrayList<>();

        int i = 0;
        while (i <= 9) {
            lList.add((char) (i + '0'));
            i++;
        }


        while (true) {
            if (StdDraw.hasNextKeyTyped()) {
                String lext = Character.toString(StdDraw.nextKeyTyped());
                number = number + lext;
                textUsage(number);
                if (Character.toUpperCase(number.charAt(number.length() - 1)) == 'S') {
                    break;

                }

            }
        }

        return number;
    }

    /** SAVING AND RELOADING */

    public void savePlay() {
        Utils.writeObject(new File("byow/Core/saved.txt"), new SavedItems(this));
    }

    public boolean reload() {
        File path = new File("byow/Core/saved.txt");
        if (path.exists()) {
            SavedItems savedItems = Utils.readObject(path, SavedItems.class);
            this.avatar = savedItems.avatar;
            this.seed = savedItems.seed;
            this.currentPosition = savedItems.currentPosition;
            this.isSaved = false;
            this.world = savedItems.world;
            this.ter.initialize(WIDTH, HEIGHT + HUD_HEIGHT);
            return true;
        }
        return false;
    }




    /** Validates that a room can be placed in that area, because there are no floor tiles in the area contained by
     * where the new room would go. Also check that it's not out of bounds of the grid. */
    public boolean validateRoom(int x, int y, int width, int height) {
        // check if in bounds
        if (x + width >= WIDTH || y + height >= HEIGHT) {
            return false;
        }
        // check if overlaps with other rooms
        for (int i = x; i <= x  + width; i++) {
            for (int j = y; j <= y + height; j++) {
                if (world[i][j].description().equals("floor")) {
                    return false;
                }
            }
        }
        return true;
    }

    // creates a hallway between two rooms
    public void createHallway(Room room1, Room room2, Position p1, Position p2, Random random) {
        // check if room2 contains x of position 1; if so, just vert
        if (p1.x >= room2.x && p1.x < room2.x + room2.width) {
            // p1.x is on the same x as room2
            if (p1.y > room2.y + room2.height) {
                // we're making a downward hallway from room1 to room2
                p2 = new Position(p1.x, room2.y + room2.height);
                createVertHallway(p1, p2);
            } else {
                // we're making an upward hallway from room1 to room2
                p2 = new Position(p1.x, room2.y);
                createVertHallway(p2, p1);
            }
        } else if (p1.y >= room2.y && p1.y < room2.y + room2.height) {
            // p1 is on the same y as room2
            if (p1.x > room2.x + room2.width) {
                // room1 is to the right of room2, we're making one hallway going left
                p2 = new Position(room2.x + room2.width, p1.y);
                createHorzHallway(p2, p1);
            } else {
                // room1 is to the left of room2, we're making one hallway going to the right
                p2 = new Position(room2.x, p1.y);
                createHorzHallway(p1, p2);
            }
        } else {
            // p1 and p2 are diagonal

            // if room1 is above and left of room2
            if (p1.x < p2.x && p1.y > p2.y) {
                Position pVertEnd = new Position(p1.x, p2.y +1);
                createVertHallway(p1, pVertEnd);

                Position pHorzStart = new Position(p1.x + 1, p2.y);
                createHorzHallway(pHorzStart, p2);

                // add the corner hallway
                Position corner = new Position(p1.x, p2.y);
                createCornerHallway(corner, true, true);
            } else if (p1.x > p2.x && p1.y < p2.y) {
                // if room1 is below and right of room2
                Position pHorzEnd = new Position(p1.x - 1, p2.y);
                createHorzHallway(p2, pHorzEnd);

                Position pVertStart = new Position(p1.x, p2.y - 1);
                createVertHallway(pVertStart, p1);

                // add the corner hallway
                Position corner = new Position(p1.x, p2.y);
                createCornerHallway(corner, false, false);
            } else if (p1.x > p2.x && p1.y > p2.y) {
                // if room1 is above and right of room2
                Position pVertStart = new Position(p2.x, p1.y - 1);
                createVertHallway(pVertStart, p2);

                Position pHorzStart = new Position(p2.x + 1, p1.y);
                createHorzHallway(pHorzStart, p1);

                // add the corner hallway
                Position corner = new Position(p2.x, p1.y);
                createCornerHallway(corner, false, true);
            } else {
                // if room1 is below and left of room2
                Position pHorzEnd = new Position(p2.x - 1, p1.y);
                createHorzHallway(p1, pHorzEnd);

                Position pVertEnd = new Position(p2.x, p1.y + 1);
                createVertHallway(p2, pVertEnd);

                // add the corner hallway
                Position corner = new Position(p2.x, p1.y);
                createCornerHallway(corner, true, false);
            }


        }

        // check if room2 contains y of position 1; if so, just horz
        // if room2 does not have x or y as pos1, we need to make a corner at some point!
    }

    // creates a vertical hallway from Position p1 to Position p2, going downward!!!.
    public void createVertHallway(Position p1, Position p2) {
        for (int i = p1.y; i >= p2.y; i--) {
            TETile thisTile = world[p1.x][i];
            TETile leftTile = world[p1.x - 1][i];
            TETile rightTile = world[p1.x + 1][i];
            if (thisTile.description().equals("wall") || thisTile.description().equals("floor")) {
                // this happens when you run into a hallway or another room
                world[p1.x][i] = Tileset.FLOOR; // thisTile
                // check if the next tiles over are nothing, if they are, change them to a wall
                if (thisTile.description().equals("wall") && leftTile.description().equals("nothing")) {
                    world[p1.x - 1][i] = Tileset.WALL; // leftTile
                }
                if (thisTile.description().equals("wall") && rightTile.description().equals("nothing")) {
                    world[p1.x + 1][i] = Tileset.WALL; // rightTile
                }
            } else {
                // this is for normal when the tile is nothing
                world[p1.x][i] = Tileset.FLOOR; // thisTile
                world[p1.x - 1][i] = Tileset.WALL; // leftTile
                world[p1.x + 1][i] = Tileset.WALL; // rightTile
            }
        }
    }

    // creates a horizontal hallway from position p1 to position p2, going to the right!!!
    public void createHorzHallway(Position p1, Position p2) {
        for (int i = p1.x; i <= p2.x; i++) {
            TETile thisTile = world[i][p1.y];
            TETile aboveTile = world[i][p1.y + 1];
            TETile belowTile = world[i][p1.y - 1];

            if (thisTile.description().equals("wall") || thisTile.description().equals("floor")) {
                // this happens when you run into a hallway or another room
                // check if the next tiles over are nothing, if they are, change them to a wall
                if (thisTile.description().equals("wall") && aboveTile.description().equals("nothing")) {
                    world[i][p1.y + 1] = Tileset.WALL; // above tile
                }
                if (thisTile.description().equals("wall") && belowTile.description().equals("nothing")) {
                    world[i][p1.y - 1] = Tileset.WALL; // below tile
                }
                world[i][p1.y] = Tileset.FLOOR; // turn thisTile into floor
            } else {
                // this is for normal cases when the tile is nothing
                world[i][p1.y] = Tileset.FLOOR; // thisTile
                world[i][p1.y + 1] = Tileset.WALL; // above tile
                world[i][p1.y - 1] = Tileset.WALL; // below tile
            }
        }
    }

    // creates a corner hallway to combine hallways
    public void createCornerHallway(Position corner, boolean top, boolean right) {
        TETile thisTile = world[corner.x][corner.y];
        if (!thisTile.description().equals("floor")) {
            if (top && right) {
                // this hallway is a corner for a hallway above it and to the right of it
                world[corner.x][corner.y] = Tileset.FLOOR; // thisTile
                if (!world[corner.x-1][corner.y].description().equals("floor")) {
                    world[corner.x-1][corner.y] = Tileset.WALL; // left tile
                }
                if (!world[corner.x][corner.y-1].description().equals("floor")) {
                    world[corner.x][corner.y-1] = Tileset.WALL; // bottom tile
                }
                if (!world[corner.x-1][corner.y-1].description().equals("floor")) {
                    world[corner.x-1][corner.y-1] = Tileset.WALL; // bottom-left diagonal tile
                }
                // only change tiles to wall if they are not already a floor tile!

            } else if ((!top) && right) {
                // this corner connects a hallway to the bottom and right of it
                world[corner.x][corner.y] = Tileset.FLOOR; // thisTile
                if (!world[corner.x - 1][corner.y].description().equals("floor")) {
                    world[corner.x - 1][corner.y] = Tileset.WALL; // left tile
                }
                if (!world[corner.x][corner.y + 1].description().equals("floor")) {
                    world[corner.x][corner.y + 1] = Tileset.WALL; // top tile
                }
                if (!world[corner.x - 1][corner.y + 1].description().equals("floor")) {
                    world[corner.x - 1][corner.y + 1] = Tileset.WALL; // top-left diagonal tile
                }
                // FIXME this is getting called when it's not supposed to
            } else if (top && (!right)) {
                // this corner connects a hallway to the top and left of it
                world[corner.x][corner.y] = Tileset.FLOOR; // thisTile
                if (!world[corner.x + 1][corner.y].description().equals("floor")) {
                    world[corner.x + 1][corner.y] = Tileset.WALL; // right tile
                }
                if (!world[corner.x][corner.y-1].description().equals("floor")) {
                    world[corner.x][corner.y-1] = Tileset.WALL; // bottom tile
                }
                if (!world[corner.x + 1][corner.y-1].description().equals("floor")) {
                    world[corner.x + 1][corner.y-1] = Tileset.WALL; // bottom-right diagonal tile
                }

            } else {
                // this corner connects a hallway to the bottom and left of it
                world[corner.x][corner.y] = Tileset.FLOOR; // thisTile
                if (!world[corner.x + 1][corner.y].description().equals("floor")) {
                    world[corner.x + 1][corner.y] = Tileset.WALL; // right tile
                }
                if (!world[corner.x][corner.y + 1].description().equals("floor")) {
                    world[corner.x][corner.y + 1] = Tileset.WALL; // top tile
                }
                if (!world[corner.x + 1][corner.y + 1].description().equals("floor")) {
                    world[corner.x + 1][corner.y + 1] = Tileset.WALL; // top-right diagonal tile
                }
            }
        }
        // if this tile is already a floor tile, that means the square is already a room, so shouldn't change
    }
    //create walls for the hallway and walls
    private void walls(Room rWalls) {
        for (int side = rWalls.x; side <= rWalls.x + rWalls.width; side++) {

            world[side][rWalls.y] = Tileset.WALL;
            world[side][rWalls.y + rWalls.height] = Tileset.WALL;
        }
        for (int rBottom = rWalls.y; rBottom <= rWalls.y + rWalls.height; rBottom++) { // add walls to side bottom
            world[rWalls.x][rBottom] = Tileset.WALL;

            // not sure about this one
            world[rWalls.x + rWalls.width][rBottom] = Tileset.WALL;
        }
    }

    public void createRoom(Random currRandom) {

        int minRS = MINRS;

        int numRooms = currRandom.nextInt(MAXS) + MINS;
        ArrayList<Room> rooms = new ArrayList<>();

        for (int i = 0; i < numRooms; i++) {
            int rWid = currRandom.nextInt(MAXRS - minRS) + minRS;
            int rHei = currRandom.nextInt(MAXRS - minRS) + minRS;

            int x = currRandom.nextInt(WIDTH - rWid);
            int y = currRandom.nextInt(HEIGHT - rHei);
            boolean lap = false;

            if (validateRoom(x, y, rWid, rHei)) {
                Room newR = new Room(x, y, rWid, rHei);
                rooms.add(newR);
                for (Room newRoominWorld : rooms) {
                    for (int xrooms = newRoominWorld.x; xrooms < newRoominWorld.x + newRoominWorld.width; xrooms++) {
                        for (int yrooms = newRoominWorld.y;
                             yrooms < newRoominWorld.y + newRoominWorld.height; yrooms++) {
                            world[xrooms][yrooms] = Tileset.FLOOR;
                        }
                    }
                }
            }
        }
        for (Room walls : rooms) {
            walls(walls);
        } for (int i = 0; i < rooms.size(); i++) {
            if (i != 0) {

                Room prevRoom = rooms.get(i - 1);

                Room currRoom = rooms.get(i);

                int prevRandX = RandomUtils.uniform(currRandom, 1, prevRoom.width - 1);
                int prevRandY = RandomUtils.uniform(currRandom, 1, prevRoom.height - 1);
                int currRandX = RandomUtils.uniform(currRandom, 1, currRoom.width - 1);
                int currRandY = RandomUtils.uniform(currRandom, 1, currRoom.height - 1);
                Position r1pos = new Position(prevRoom.x + prevRandX, prevRoom.y + prevRandY);
                Position r2pos = new Position(currRoom.x + currRandX, currRoom.y + currRandY);
                createHallway(prevRoom, currRoom, r1pos, r2pos,  currRandom);
            }
        }
        spawnAvatar(Tileset.COWGIRL, currRandom);

    }

    /** HANDLING AVATARS */

    // TODO make sure that the args are valid args, because this function doesn't check for that
    // This function checks which avatar is selected in the menu.
    public TETile whichAvatar(char input) {
        if (input == 'X') {
            // case where avatar is Stereotypical Barbie
            return Tileset.STEREOTYPICAL;
        } else {
            // case where avatar is Cowgirl Barbie
            return Tileset.COWGIRL;
        }
    }

    // This function spawns the given avatar in the world during generation.
    public void spawnAvatar(TETile avatar, Random currRandom) {
        boolean roomFound = false;
        while(!roomFound) {
            int x = currRandom.nextInt(WIDTH - 1);
            int y = currRandom.nextInt(HEIGHT - 1);
            if (world[x][y].description().equals("floor")) {
                roomFound = true;
                world[x][y] = avatar;
                currentPosition = new Position(x,y);
            }
        }
    }

    /** MOVEMENT FUNCTIONS */

    public void moveLeft () {
        // if you're moving left, the x decreases and y stays same
        TETile currAvatar = world[currentPosition.x][currentPosition.y];
        if (world[currentPosition.x - 1][currentPosition.y].description().equals("floor")) {
            world[currentPosition.x - 1][currentPosition.y] = currAvatar;
            world[currentPosition.x][currentPosition.y] = Tileset.FLOOR;
            // return the new current Position
            this.currentPosition = new Position(currentPosition.x - 1, currentPosition.y);
        }

    }

    public void moveRight () {
        // if you're moving right, the x increases and y stays same
        TETile currAvatar = world[currentPosition.x][currentPosition.y];
        if (world[currentPosition.x + 1][currentPosition.y].description().equals("floor")) {
            world[currentPosition.x + 1][currentPosition.y] = currAvatar;
            world[currentPosition.x][currentPosition.y] = Tileset.FLOOR;
            // return the new current Position
            currentPosition = new Position(currentPosition.x + 1, currentPosition.y);
        }

    }

    public void moveUp () {
        // if you're moving up, the x stays the same and y increases
        TETile currAvatar = world[currentPosition.x][currentPosition.y];
        if (world[currentPosition.x][currentPosition.y + 1].description().equals("floor")) {
            world[currentPosition.x][currentPosition.y + 1] = currAvatar;
            world[currentPosition.x][currentPosition.y] = Tileset.FLOOR;
            currentPosition = new Position(currentPosition.x, currentPosition.y + 1);
        }
    }

    public void moveDown () {
        // if you're moving down, the x stays the same and y decreases
        TETile currAvatar = world[currentPosition.x][currentPosition.y];
        if (world[currentPosition.x][currentPosition.y - 1].description().equals("floor")) {
            world[currentPosition.x][currentPosition.y - 1] = currAvatar;
            world[currentPosition.x][currentPosition.y] = Tileset.FLOOR;
            currentPosition = new Position(currentPosition.x, currentPosition.y - 1);
        }
    }

    /** OTHER DISPLAY RELATED FUNCTIONS */

    // This function creates a HUD on the display based on where the mouse is.
    public void hud() {
        int xInt = (int) StdDraw.mouseX();
        int yInt = (int) StdDraw.mouseY();
        if (xInt < WIDTH && yInt < HEIGHT) {
            StdDraw.enableDoubleBuffering();
            Font optionsFont = new Font("Monaco", Font.BOLD, TILE_SIZE*3/4);
            StdDraw.setFont(optionsFont);
            StdDraw.setPenColor(Color.white);
            String d = world[xInt][yInt].description();
            StdDraw.textLeft(1, HEIGHT - 1, d);
            StdDraw.show();
        }
    }

    /*public void hud() {
        int radius = 5;
        int xInt = (int) StdDraw.mouseX();
        int yInt = (int) StdDraw.mouseY();
        int startX = Math.max(0, currentPosition.x - radius);
        int endX = Math.min(WIDTH - 1, currentPosition.x + radius);
        int startY = Math.max(0, currentPosition.y - radius);
        int endY = Math.min(HEIGHT - 1, currentPosition.y + radius);
        Font optionsFont = new Font("Monaco", Font.BOLD, TILE_SIZE * 3 / 4);
        StdDraw.setFont(optionsFont);
        StdDraw.setPenColor(Color.white);
        // Display only the visible tiles within the radius around the avatar
        if (xInt < WIDTH && yInt < HEIGHT) {
            StdDraw.enableDoubleBuffering();
            String d = world[xInt][yInt].description();
            StdDraw.textLeft(1, HEIGHT - 1, d);
            for (int y = startY; y <= endY; y++) {
                for (int x = startX; x <= endX; x++) {
                    String b = world[x][y].description();
                    StdDraw.textLeft(1, HEIGHT - y, b);
                    if (xInt >= startX && xInt <= endX && yInt >= startY && yInt <= endY) {
                        String hoveredTileDescription = world[xInt][yInt].description();
                        StdDraw.textLeft(1, HEIGHT - yInt, hoveredTileDescription);
                    }
                }
            }
            StdDraw.show();

        }
    }*/
}

