package byow.Core;

import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;

public class MusicPlayer {
    // @source https://www.youtube.com/watch?v=57XzN-O6E2g

    public static void PlayMusic(String filepath) {

        File musicPath = new File(filepath);

        try {
            AudioInputStream input = AudioSystem.getAudioInputStream(musicPath); // start getting the data from the file
            // make an audio clip and open it up and give it the data from our file
            Clip musicClip = AudioSystem.getClip();
            musicClip.open(input);
            // loop the audio clip
            musicClip.loop(5);
            // TODO change this to continuous when ready!!
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (UnsupportedAudioFileException e) {
            throw new RuntimeException(e);
        } catch (LineUnavailableException e) {
            throw new RuntimeException(e);
        }

    }

    // @source of audio files: https://4kdownload.to/en1/youtube-wav-downloader
    public static void PlaySoundEffect(String filepath) {

        File musicPath = new File(filepath);

        try {
            AudioInputStream input = AudioSystem.getAudioInputStream(musicPath); // start getting the data from the file
            // make an audio clip and open it up and give it the data from our file
            Clip musicClip = AudioSystem.getClip();
            musicClip.open(input);
            // loop the audio clip
            musicClip.loop(0);
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (UnsupportedAudioFileException e) {
            throw new RuntimeException(e);
        } catch (LineUnavailableException e) {
            throw new RuntimeException(e);
        }

    }



}